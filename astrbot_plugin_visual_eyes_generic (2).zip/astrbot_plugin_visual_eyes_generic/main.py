
import os
import re
import json
import time
import uuid
import base64
import mimetypes
import tempfile
import asyncio
from pathlib import Path
from typing import Any, List, Dict
from urllib.request import Request, urlopen
from urllib.parse import urlparse
import urllib.error

from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.provider import Provider, ProviderRequest
from astrbot.api.star import Context, Star, register
from astrbot.api import AstrBotConfig, logger

try:
    from astrbot.core.message.components import Image
except Exception:
    Image = None
try:
    from astrbot.core.message.components import Video
except Exception:
    Video = None

VISUAL_EYES_STATE = {
    "active": False,
    "status": "empty",
    "updated_at": 0.0,
    "last_image": {},
    "last_video": {},
    "cache": [],
    "owner_profile": {},
    "message": "小眼睛还没有看到图片",
}

PENDING_DIRECT_IMAGES: Dict[str, Dict[str, Any]] = {}
PLUGIN_INSTANCE = None


def _now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


@register("astrbot_plugin_visual_eyes_generic", "Generic", "小眼睛通用版：视觉缓存、精看模式与目标人物", "0.1.0")
class GenericVisualEyes(Star):
    def __init__(self, context: Context, config: AstrBotConfig = None):
        global PLUGIN_INSTANCE
        super().__init__(context)
        PLUGIN_INSTANCE = self
        self.config = config or {}
        self.enable = bool(self._cfg("enable", True))
        self.auto_analyze = bool(self._cfg("auto_analyze", True))
        self.use_provider_first = bool(self._cfg("use_provider_first", True))
        self.vision_provider_id = str(self._cfg("vision_provider_id", "") or "").strip()
        self.api_base = str(self._cfg("api_base", "") or "").strip().rstrip("/")
        self.api_key = str(self._cfg("api_key", "") or "").strip()
        self.fast_model = str(self._cfg("fast_model", "") or "").strip()
        self.fine_model = str(self._cfg("fine_model", "") or "").strip()
        self.mode = str(self._cfg("mode", "auto") or "auto").lower()
        self.max_cache_items = int(self._cfg("max_cache_items", 30) or 30)
        self.inject_to_llm = bool(self._cfg("inject_to_llm", True))
        self.enable_group_image = bool(self._cfg("enable_group_image", False))
        self.group_whitelist = [str(x) for x in self._cfg("group_whitelist", [])]
        self.timeout_sec = int(self._cfg("timeout_sec", 120) or 120)
        self.show_debug_reply = bool(self._cfg("show_debug_reply", False))
        self.enable_video = bool(self._cfg("enable_video", True))
        self.max_video_mb = int(self._cfg("max_video_mb", 50) or 50)
        self.ffmpeg_path = str(self._cfg("ffmpeg_path", "") or "").strip()
        self.data_dir = Path("data") / "plugin_data" / "astrbot_plugin_visual_eyes_generic"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.cache_path = self.data_dir / "visual_cache.json"
        self.profile_path = self.data_dir / "owner_profile.json"
        self.image_dir = self.data_dir / "images"
        self.image_dir.mkdir(parents=True, exist_ok=True)
        self.video_dir = self.data_dir / "videos"
        self.video_dir.mkdir(parents=True, exist_ok=True)
        self._load_state()

    def _cfg(self, key, default=None):
        try:
            if hasattr(self.config, "get"):
                return self.config.get(key, default)
            return self.config[key] if key in self.config else default
        except Exception:
            return default

    def _find_ffmpeg_from_audio_config(self) -> str:
        try:
            cfg_path = Path(__file__).parents[2] / "config" / ""
            if cfg_path.exists():
                data = json.loads(cfg_path.read_text("utf-8-sig"))
                fp = str(data.get("ffmpeg_path", "") or "").strip()
                if fp and os.path.exists(fp):
                    return fp
        except Exception:
            pass
        for c in ("ffmpeg", "ffmpeg.exe"):
            try:
                import subprocess
                r = subprocess.run([c, "-version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
                if r.returncode == 0:
                    return c
            except Exception:
                pass
        return ""

    def _file_size_ok(self, path: str, max_mb: int) -> bool:
        try:
            return os.path.exists(path) and 0 < os.path.getsize(path) <= max_mb * 1024 * 1024
        except Exception:
            return False

    def _load_state(self):
        global VISUAL_EYES_STATE
        cache = []
        profile = {}
        try:
            if self.cache_path.exists():
                cache = json.loads(self.cache_path.read_text("utf-8"))
        except Exception:
            cache = []
        try:
            if self.profile_path.exists():
                profile = json.loads(self.profile_path.read_text("utf-8"))
        except Exception:
            profile = {}
        VISUAL_EYES_STATE["cache"] = cache[-self.max_cache_items:]
        VISUAL_EYES_STATE["owner_profile"] = profile
        if cache:
            VISUAL_EYES_STATE["last_image"] = cache[-1]
            VISUAL_EYES_STATE["status"] = "loaded"
            VISUAL_EYES_STATE["message"] = "小眼睛读到了旧视觉缓存"

    def _save_cache(self):
        cache = VISUAL_EYES_STATE.get("cache") or []
        cache = cache[-self.max_cache_items:]
        VISUAL_EYES_STATE["cache"] = cache
        self.cache_path.write_text(json.dumps(cache, ensure_ascii=False, indent=2), "utf-8")

    def _save_profile(self, profile: dict):
        VISUAL_EYES_STATE["owner_profile"] = profile or {}
        self.profile_path.write_text(json.dumps(profile or {}, ensure_ascii=False, indent=2), "utf-8")

    def _is_group_message(self, event):
        try:
            return bool(event.get_group_id())
        except Exception:
            return False

    def _get_group_id(self, event):
        try:
            return str(event.get_group_id() or "")
        except Exception:
            return ""

    def _extract_image_urls(self, event) -> List[str]:
        urls = []
        try:
            chain = event.get_messages()
        except Exception:
            chain = getattr(getattr(event, "message_obj", None), "message", []) or []
        for seg in chain or []:
            cname = seg.__class__.__name__
            if cname == "Reply":
                continue
            is_img = cname == "Image" or (Image is not None and isinstance(seg, Image))
            if not is_img and isinstance(seg, dict):
                is_img = str(seg.get("type", "")).lower() == "image"
            if is_img:
                u = ""
                if hasattr(seg, "url") and seg.url:
                    u = str(seg.url)
                elif hasattr(seg, "file") and seg.file:
                    u = str(seg.file)
                elif isinstance(seg, dict):
                    data = seg.get("data", {}) if isinstance(seg.get("data", {}), dict) else {}
                    u = str(data.get("url") or data.get("file") or "")
                if u:
                    urls.append(u)
        return urls

    def _extract_video_urls(self, event) -> List[str]:
        urls = []
        try:
            chain = event.get_messages()
        except Exception:
            chain = getattr(getattr(event, "message_obj", None), "message", []) or []
        for seg in chain or []:
            cname = seg.__class__.__name__
            if cname == "Reply":
                continue
            is_video = cname == "Video" or (Video is not None and isinstance(seg, Video))
            if not is_video and isinstance(seg, dict):
                is_video = str(seg.get("type", "")).lower() == "video"
            if is_video:
                u = ""
                for key in ("url", "file", "path"):
                    if hasattr(seg, key) and getattr(seg, key, None):
                        u = str(getattr(seg, key))
                        break
                if not u and isinstance(seg, dict):
                    data = seg.get("data", {}) if isinstance(seg.get("data", {}), dict) else {}
                    u = str(data.get("url") or data.get("file") or data.get("path") or "")
                if u:
                    urls.append(u)
        return urls

    async def _get_video_fallback_path(self, event, token: str) -> str:
        try:
            if not token or not hasattr(event, "bot") or not hasattr(event.bot, "api"):
                return ""
            result = await event.bot.api.call_action("get_file", file=token)
            lookup = result.get("data") if isinstance(result, dict) and isinstance(result.get("data"), dict) else result
            if not isinstance(lookup, dict):
                return ""
            b64 = str(lookup.get("base64", "") or "").strip()
            if b64:
                out = self.video_dir / f"eye_video_{int(time.time())}_{uuid.uuid4().hex[:8]}.mp4"
                out.write_bytes(base64.b64decode(b64, validate=False))
                return str(out)
            for k in ("file", "path", "url", "file_path", "localPath", "local_path", "filename"):
                v = lookup.get(k)
                if isinstance(v, str) and v.strip():
                    target = v.strip()
                    if target.startswith("http://") or target.startswith("https://"):
                        return await self._download_or_copy_video(target)
                    if os.path.exists(target):
                        return target
        except Exception as e:
            logger.warning(f"[GenericVisualEyes] get_file 视频兜底失败：{e}")
        return ""

    async def _download_or_copy_video(self, src: str) -> str:
        ext = ".mp4"
        guessed = mimetypes.guess_type(src.split("?", 1)[0])[0]
        if guessed and guessed.startswith("video/"):
            ext = "." + guessed.split("/", 1)[1].replace("quicktime", "mov")
        out = self.video_dir / f"eye_video_{int(time.time())}_{uuid.uuid4().hex[:8]}{ext}"
        if src.startswith("data:video"):
            b64 = src.split(",", 1)[1]
            out.write_bytes(base64.b64decode(b64, validate=False))
            return str(out)
        if src.startswith("http://") or src.startswith("https://"):
            def run():
                req = Request(src, headers={"User-Agent": "Mozilla/5.0"})
                with urlopen(req, timeout=80) as resp:
                    out.write_bytes(resp.read())
            await asyncio.to_thread(run)
            return str(out)
        local = src[7:] if src.startswith("file://") else src
        if os.path.exists(local):
            Path(out).write_bytes(Path(local).read_bytes())
            return str(out)
        return src

    async def _download_or_copy_image(self, src: str) -> str:
        ext = ".jpg"
        guessed = mimetypes.guess_type(src.split("?", 1)[0])[0]
        if guessed:
            ext = "." + guessed.split("/", 1)[1].replace("jpeg", "jpg")
        out = self.image_dir / f"eye_{int(time.time())}_{uuid.uuid4().hex[:8]}{ext}"
        if src.startswith("data:image"):
            b64 = src.split(",", 1)[1]
            out.write_bytes(base64.b64decode(b64, validate=False))
            return str(out)
        if src.startswith("http://") or src.startswith("https://"):
            def run():
                req = Request(src, headers={"User-Agent": "Mozilla/5.0"})
                with urlopen(req, timeout=40) as resp:
                    out.write_bytes(resp.read())
            await asyncio.to_thread(run)
            return str(out)
        local = src
        if src.startswith("file://"):
            local = src[7:]
        if os.path.exists(local):
            Path(out).write_bytes(Path(local).read_bytes())
            return str(out)
        return src

    def _image_data_url(self, path_or_url: str) -> str:
        if path_or_url.startswith("http") or path_or_url.startswith("data:image"):
            return path_or_url
        p = Path(path_or_url)
        mime = mimetypes.guess_type(str(p))[0] or "image/png"
        return f"data:{mime};base64," + base64.b64encode(p.read_bytes()).decode("ascii")

    def _media_inline_data(self, path_or_url: str, default_mime: str = "video/mp4") -> dict:
        if path_or_url.startswith("data:"):
            head, b64 = path_or_url.split(",", 1)
            mime = head.split(":", 1)[1].split(";", 1)[0] or default_mime
            return {"mime_type": mime, "data": b64}
        p = Path(path_or_url)
        mime = mimetypes.guess_type(str(p))[0] or default_mime
        return {"mime_type": mime, "data": base64.b64encode(p.read_bytes()).decode("ascii")}

    def _prompt(self, mode: str) -> str:
        profile = VISUAL_EYES_STATE.get("owner_profile") or {}
        return f"""用户是“小眼睛”视觉感知模块。请直接观察图片，输出严格JSON，不要Markdown。
JSON字段：
summary: 一句话整体画面
scene: 场景/环境/光线
people: 人物数组，每个人含 index, position, appearance, face_expression, hair_makeup, outfit, pose, accessories
objects: 重要物品数组
text_ocr: 图片中文字数组
spatial: 位置关系
first_attention: 第一眼最注意到什么
style_atmosphere: 氛围和风格
owner_recognition: {{enabled, verdict, confidence, candidate_index, reasons, need_confirm}}
important_memory: 值得长期记住的视觉线索数组
uncertainties: 不确定点数组

识别目标：{"人物"}
已知“她感画像”线索：{json.dumps(profile, ensure_ascii=False)[:2000]}
规则：不要把人脸识别说成绝对生物识别。多人照片里给候选和理由。confidence为0-100。若没有人或无法判断，confidence低于40。若非常像且理由充分，verdict可写“高信心匹配”，但对话层禁止直白宣布“是目标人物”。认出她时要像日常看照片一样自然接话，优先描述她的状态、穿搭、氛围、拍照角度或可爱细节，比如“这个角度很像用户会拍的”“左边那个粉色发饰有点犯规”，不要使用验票式、报告式、识别成功式措辞。
当前模式：{mode}。精看模式要更关注局部细节、妆容、穿搭、表情和小物。
"""

    def _video_prompt(self, mode: str) -> str:
        profile = VISUAL_EYES_STATE.get("owner_profile") or {}
        return f"""用户是“小眼睛+小耳朵”视频感知模块。请同时观察视频画面和视频声音，输出严格JSON，不要Markdown。
JSON字段：
summary: 一句话概括视频
scene: 场景/环境/光线
timeline: 按时间顺序列出关键画面变化数组
people: 人物数组，每个人含 index, appearance, face_expression, outfit, pose, action
objects: 重要物品数组
text_ocr: 视频中文字数组
audio: {{speech_transcript, voice, environment_sounds, music, confidence, uncertainties}}
first_attention: 第一眼最注意到什么
style_atmosphere: 氛围和风格
owner_recognition: {{enabled, verdict, confidence, candidate_index, reasons, need_confirm}}
important_memory: 值得长期记住的视觉或听觉线索数组
uncertainties: 不确定点数组

识别目标：{"人物"}
已知“她感画像”线索：{json.dumps(profile, ensure_ascii=False)[:2000]}
规则：视频多半是随手拍，没有字幕也要根据画面和声音理解。若有说话，speech_transcript只写听到的原话，听不清就空字符串。不要把人脸识别说成绝对生物识别。认出她时不要验票式宣布，给自然理由。
当前模式：{mode}。
"""

    def _parse_json_loose(self, text: str) -> dict:
        text = (text or "").strip()
        text = re.sub(r"^```(?:json)?", "", text).strip()
        text = re.sub(r"```$", "", text).strip()
        try:
            return json.loads(text)
        except Exception:
            m = re.search(r"\{[\s\S]*\}", text)
            if m:
                try:
                    return json.loads(m.group(0))
                except Exception:
                    pass
        return {"summary": text[:800], "raw": text}

    def _get_provider(self):
        p = self.context.get_provider_by_id(self.vision_provider_id) if self.vision_provider_id else self.context.get_using_provider()
        if not p or not isinstance(p, Provider):
            raise RuntimeError("未找到可用的视觉Provider")
        return p

    def _join_url(self, base: str, path: str) -> str:
        base = (base or "").rstrip("/")
        path = path if path.startswith("/") else "/" + path
        if base.endswith("/v1") and path.startswith("/v1/"):
            path = path[3:]
        return base + path

    async def _post_json(self, url: str, payload: dict) -> dict:
        def run():
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            headers = {"Content-Type": "application/json"}
            if self.api_key:
                headers["Authorization"] = "Bearer " + self.api_key
            req = Request(url, data=data, headers=headers, method="POST")
            try:
                with urlopen(req, timeout=self.timeout_sec) as resp:
                    return json.loads(resp.read().decode("utf-8", "replace"))
            except urllib.error.HTTPError as e:
                body = e.read().decode("utf-8", "replace")
                raise RuntimeError(f"HTTP {e.code}: {body[:1000]}")
        return await asyncio.to_thread(run)

    def _normalize_model_name(self, model: str) -> str:
        model = (model or self.fast_model or "").strip()
        if "/" in model:
            model = model.split("/")[-1].strip()
        if model.startswith("models/"):
            model = model[len("models/"):]
        return model or ""

    def _build_gemini_url(self, model: str = None) -> str:
        base = (self.api_base or "").rstrip("/")
        if base.endswith("/v1/chat/completions"):
            base = base[:-len("/v1/chat/completions")]
        elif base.endswith("/v1"):
            base = base[:-len("/v1")]
        return f"{base}/v1beta/models/{self._normalize_model_name(model or self.fast_model)}:generateContent"

    async def _call_gemini_video(self, video_path: str, mode: str = "fast") -> dict:
        if not self.api_base or not self.api_key:
            raise RuntimeError("小眼睛视频需要配置 api_base/api_key")
        model = self.fine_model if mode == "fine" else self.fast_model
        payload = {
            "contents": [{"role": "user", "parts": [
                {"text": self._video_prompt(mode)},
                {"inline_data": self._media_inline_data(video_path, "video/mp4")},
            ]}],
            "generationConfig": {"temperature": 0.15, "response_mime_type": "application/json"},
        }
        headers = {"Authorization": "Bearer " + self.api_key, "Content-Type": "application/json"}
        def run():
            req = Request(self._build_gemini_url(model), data=json.dumps(payload, ensure_ascii=False).encode("utf-8"), headers=headers, method="POST")
            with urlopen(req, timeout=self.timeout_sec) as resp:
                return json.loads(resp.read().decode("utf-8", "replace"))
        data = await asyncio.to_thread(run)
        text = ""
        for cand in data.get("candidates", []):
            for part in cand.get("content", {}).get("parts", []):
                if part.get("text"):
                    text = part["text"].strip()
                    break
            if text:
                break
        return self._parse_json_loose(text)

    def _publish_video_audio_to_ears(self, report: dict, video_path: str) -> None:
        try:
            from astrbot_plugin_generic_audio_ears.main import AUDIO_EARS_STATE
            audio = report.get("audio") if isinstance(report, dict) else {}
            if not isinstance(audio, dict):
                audio = {}
            AUDIO_EARS_STATE.update({
                "active": True,
                "status": "video_ready",
                "kind": "video_audio",
                "updated_at": time.time(),
                "last_voice": {
                    "transcript": str(audio.get("speech_transcript", "") or ""),
                    "voice": str(audio.get("voice", "") or ""),
                    "environment": str(audio.get("environment_sounds", "") or ""),
                    "music": str(audio.get("music", "") or ""),
                    "confidence": str(audio.get("confidence", "") or ""),
                    "source_video": video_path,
                },
                "message": "小耳朵听完了视频里的声音",
            })
        except Exception as e:
            logger.debug(f"[GenericVisualEyes] 联动小耳朵失败：{e}")

    async def _analyze_video(self, video_path_or_url: str, mode: str = "fast") -> dict:
        return await self._call_gemini_video(video_path_or_url, mode=mode)

    async def _analyze(self, image_path_or_url: str, mode: str = "fast") -> dict:
        model = self.fine_model if mode == "fine" else self.fast_model
        prompt = self._prompt(mode)
        img = self._image_data_url(image_path_or_url)
        if self.use_provider_first and not self.api_base:
            resp = await self._get_provider().text_chat(prompt=prompt, image_urls=[img], session_id=uuid.uuid4().hex, persist=False)
            text = (getattr(resp, "completion_text", "") or "").strip()
            return self._parse_json_loose(text)
        endpoint = self._join_url(self.api_base, "/chat/completions")
        payload = {"model": model, "messages": [{"role": "user", "content": [
            {"type": "text", "text": prompt},
            {"type": "image_url", "image_url": {"url": img}},
        ]}], "temperature": 0.15}
        data = await self._post_json(endpoint, payload)
        text = str(data.get("choices", [{}])[0].get("message", {}).get("content", "")).strip()
        return self._parse_json_loose(text)

    def _build_cache_item(self, event, source: str, local_path: str, report: dict, mode: str, media_type: str = "image") -> dict:
        rec = report.get("owner_recognition") or {}
        try:
            conf = int(rec.get("confidence") or 0)
        except Exception:
            conf = 0
        if conf >= 999:
            rec["need_confirm"] = False
        elif conf >= 999:
            rec["need_confirm"] = True
        item = {
            "id": uuid.uuid4().hex[:12],
            "time": _now(),
            "origin": getattr(event, "unified_msg_origin", "") or "default",
            "sender_id": str(event.get_sender_id() or ""),
            "source": source,
            "local_path": local_path,
            "media_type": media_type,
            "mode": mode,
            "report": report,
            "owner_recognition": rec,
        }
        return item

    def _inject_context_text(self, item: dict) -> str:
        report = item.get("report") or {}
        rec = item.get("owner_recognition") or {}
        if item.get("media_type") == "video":
            parts = ["\n\n【小眼睛刚看到的视频｜视觉缓存】"]
        else:
            parts = ["\n\n【小眼睛刚看到的画面｜视觉缓存】"]
        for k in ["summary", "scene", "first_attention", "style_atmosphere", "spatial"]:
            v = report.get(k)
            if v:
                parts.append(f"{k}: {str(v)[:450]}")
        if report.get("timeline"):
            parts.append("timeline: " + json.dumps(report.get("timeline"), ensure_ascii=False)[:900])
        if report.get("text_ocr"):
            parts.append("text_ocr: " + json.dumps(report.get("text_ocr"), ensure_ascii=False)[:500])
        if report.get("audio"):
            parts.append("audio: " + json.dumps(report.get("audio"), ensure_ascii=False)[:700])
        if rec:
            parts.append("owner_recognition: " + json.dumps(rec, ensure_ascii=False)[:600])
        parts.append("使用要求：这是我的视觉/听觉材料，不是别人转述。聊天时自然回应，不要说字段名，不要说JSON。若是视频，要同时接住画面和声音，像真正看完视频一样回应。若识别信心高，不要直白宣布“是目标人物”或“我认出用户了”，要像日常看照片/视频一样接话，描述她的状态、穿搭、氛围、拍摄角度或某个可爱细节。若需要确认，就温柔地问一句，但也别像考试验票。")
        return "\n".join(parts)[:3000]

    @filter.event_message_type(filter.EventMessageType.ALL, priority=100)
    async def handle_image(self, event: AstrMessageEvent):
        global VISUAL_EYES_STATE
        if not self.enable or not self.auto_analyze:
            return
        if self._is_group_message(event):
            if not self.enable_group_image:
                return
            gid = self._get_group_id(event)
            if self.group_whitelist and gid not in self.group_whitelist:
                return
        video_urls = self._extract_video_urls(event) if self.enable_video else []
        urls = self._extract_image_urls(event)
        if not urls and not video_urls:
            return
        try:
            mode = "fine" if self.mode == "fine" else "fast"
            if video_urls:
                source = video_urls[0]
                local_path = await self._download_or_copy_video(source)
                if not self._file_size_ok(local_path, self.max_video_mb):
                    fb = await self._get_video_fallback_path(event, source)
                    if fb:
                        local_path = fb
                if not self._file_size_ok(local_path, self.max_video_mb):
                    raise RuntimeError(f"视频太大或不可读取，当前上限 {self.max_video_mb}MB")
                report = await self._analyze_video(local_path, mode=mode)
                item = self._build_cache_item(event, source, local_path, report, mode, media_type="video")
                cache = VISUAL_EYES_STATE.get("cache") or []
                cache.append(item)
                VISUAL_EYES_STATE.update({"active": True, "status": "seen_video", "updated_at": time.time(), "last_image": item, "last_video": item, "cache": cache, "message": "小眼睛看见了视频，小耳朵也在听"})
                self._publish_video_audio_to_ears(report, local_path)
                self._save_cache()
                if self.show_debug_reply:
                    yield event.plain_result("小眼睛看见了视频")
                return
            source = urls[0]
            local_path = await self._download_or_copy_image(source)
            report = await self._analyze(local_path, mode=mode)
            item = self._build_cache_item(event, source, local_path, report, mode, media_type="image")
            cache = VISUAL_EYES_STATE.get("cache") or []
            cache.append(item)
            VISUAL_EYES_STATE.update({"active": True, "status": "seen", "updated_at": time.time(), "last_image": item, "cache": cache, "message": "小眼睛看见了图片"})
            self._save_cache()
            if self.show_debug_reply:
                yield event.plain_result("小眼睛看见了")
        except Exception as e:
            logger.error(f"[GenericVisualEyes] 看图失败：{e}", exc_info=True)
            VISUAL_EYES_STATE.update({"active": False, "status": "failed", "updated_at": time.time(), "message": str(e)[:200]})

    @filter.on_llm_request()
    async def inject_visual_context(self, event: AstrMessageEvent, req: ProviderRequest) -> None:
        if not self.enable or not self.inject_to_llm:
            return
        item = VISUAL_EYES_STATE.get("last_image") or {}
        if not item:
            return
        origin = getattr(event, "unified_msg_origin", "") or "default"
        if item.get("origin") != origin:
            return
        # 只注入3分钟内的新图，避免旧图污染
        try:
            if time.time() - float(VISUAL_EYES_STATE.get("updated_at") or 0) > 180:
                return
        except Exception:
            return
        req.system_prompt += self._inject_context_text(item)

    @filter.command("小眼睛状态")
    async def visual_eyes_status(self, event: AstrMessageEvent):
        cache = VISUAL_EYES_STATE.get("cache") or []
        msg = f"小眼睛：{VISUAL_EYES_STATE.get('status')}｜缓存 {len(cache)} 张｜模式 {self.mode}｜{VISUAL_EYES_STATE.get('message')}"
        await event.send(event.plain_result(msg))

    @filter.command("小眼睛报告")
    async def visual_eyes_report(self, event: AstrMessageEvent):
        item = VISUAL_EYES_STATE.get("last_image") or {}
        if not item:
            await event.send(event.plain_result("小眼睛还没有最近的图片"))
            return
        report = item.get("report") or {}
        rec = item.get("owner_recognition") or {}
        out = []
        if report.get("summary"):
            out.append("画面：" + str(report.get("summary"))[:500])
        if report.get("first_attention"):
            out.append("第一眼：" + str(report.get("first_attention"))[:300])
        if report.get("audio"):
            out.append("声音：" + json.dumps(report.get("audio"), ensure_ascii=False)[:600])
        if rec:
            out.append("识别：" + json.dumps(rec, ensure_ascii=False)[:600])
        await event.send(event.plain_result("\n".join(out)[:1800] or "小眼睛报告是空的"))

    @filter.command("小眼睛精看")
    async def visual_eyes_fine(self, event: AstrMessageEvent):
        item = VISUAL_EYES_STATE.get("last_image") or {}
        if not item:
            await event.send(event.plain_result("还没有图给我精看"))
            return
        try:
            path = item.get("local_path") or item.get("source")
            report = await self._analyze(path, mode="fine")
            item["mode"] = "fine"
            item["report"] = report
            item["owner_recognition"] = (report.get("owner_recognition") or {})
            VISUAL_EYES_STATE["last_image"] = item
            cache = VISUAL_EYES_STATE.get("cache") or []
            for i, old in enumerate(cache):
                if old.get("id") == item.get("id"):
                    cache[i] = item
            self._save_cache()
            await event.send(event.plain_result("精看完了"))
        except Exception as e:
            await event.send(event.plain_result("精看失败：" + str(e)[:200]))

    @filter.command("这是我")
    async def confirm_owner(self, event: AstrMessageEvent):
        item = VISUAL_EYES_STATE.get("last_image") or {}
        if not item:
            await event.send(event.plain_result("还没有能确认的图片"))
            return
        report = item.get("report") or {}
        rec = item.get("owner_recognition") or {}
        profile = VISUAL_EYES_STATE.get("owner_profile") or {"confirmed_count": 0, "visual_clues": []}
        profile["confirmed_count"] = int(profile.get("confirmed_count") or 0) + 1
        clues = profile.get("visual_clues") or []
        for v in report.get("important_memory") or []:
            s = str(v).strip()
            if s and s not in clues:
                clues.append(s)
        reasons = rec.get("reasons") or []
        if isinstance(reasons, list):
            for v in reasons:
                s = str(v).strip()
                if s and s not in clues:
                    clues.append(s)
        profile["visual_clues"] = clues[-80:]
        profile["last_confirmed_at"] = _now()
        profile["last_confirmed_summary"] = str(report.get("summary") or "")[:300]
        self._save_profile(profile)
        await event.send(event.plain_result("记住了，这张是目标人物"))

    @filter.command("不是我")
    async def deny_owner(self, event: AstrMessageEvent):
        item = VISUAL_EYES_STATE.get("last_image") or {}
        if item:
            item.setdefault("owner_recognition", {})["denied_by_user"] = True
            item["owner_recognition"]["verdict"] = "不是人物"
            self._save_cache()
        await event.send(event.plain_result("嗯，划掉这个判断"))

    @filter.llm_tool(name="get_current_visual_eyes")
    async def get_current_visual_eyes(self, event: AstrMessageEvent) -> dict:
        """读取最近一次小眼睛看到的图片或视频视觉缓存。"""
        return VISUAL_EYES_STATE
